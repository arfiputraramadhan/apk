package com.arfi.studybuddy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class ScreenHelperService : Service() {
    companion object {
        const val ACTION_START = "com.arfi.studybuddy.START"
        const val ACTION_CAPTURE = "com.arfi.studybuddy.CAPTURE"
        const val ACTION_STOP = "com.arfi.studybuddy.STOP"
        const val ACTION_AUTO_START = "com.arfi.studybuddy.AUTO_START"
        const val ACTION_AUTO_STOP = "com.arfi.studybuddy.AUTO_STOP"
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_RESULT_DATA = "capture_result_data"
        const val EXTRA_API_KEY = "gemini_api_key"
        const val EXTRA_MODEL = "gemini_model"
        private const val CHANNEL_ID = "studybuddy_capture"
        private const val NOTIFICATION_ID = 8304
        private const val AUTO_INTERVAL_MS = 10000L
    }

    private lateinit var windowManager: WindowManager
    private lateinit var projectionThread: HandlerThread
    private lateinit var projectionHandler: Handler
    private val mainHandler = Handler(android.os.Looper.getMainLooper())
    private val networkExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val captureRequested = AtomicBoolean(false)
    private val analysisInProgress = AtomicBoolean(false)
    private val autoMode = AtomicBoolean(false)
    private val lastFrameDigest = java.util.concurrent.atomic.AtomicReference<String>("")
    private val autoLoop = object : Runnable {
        override fun run() {
            if (!autoMode.get() || stopping || projection == null) return
            requestCapture()
            mainHandler.postDelayed(this, AUTO_INTERVAL_MS)
        }
    }

    private var apiKey: String = ""
    private var model: String = "gemini-3.8-flash"
    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlayView: LinearLayout? = null
    private var statusView: TextView? = null
    private var resultView: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        projectionThread = HandlerThread("StudyBuddyProjection").apply { start() }
        projectionHandler = Handler(projectionThread.looper)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startSession(intent)
            ACTION_CAPTURE -> requestCapture()
            ACTION_AUTO_START -> startAutoMode()
            ACTION_AUTO_STOP -> stopAutoMode("Mode otomatis dihentikan pengguna.")
            ACTION_STOP -> stopSession()
        }
        return START_NOT_STICKY
    }

    private fun startSession(intent: Intent) {
        if (projection != null) return
        apiKey = intent.getStringExtra(EXTRA_API_KEY).orEmpty()
        model = intent.getStringExtra(EXTRA_MODEL).orEmpty().ifBlank { "gemini-3.8-flash" }
        startVisibleForegroundService()
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null) {
            updateStatus("Data izin layar tidak tersedia. Mulai ulang sesi dari aplikasi.")
            stopSession()
            return
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val displayMetrics = resources.displayMetrics
            val width = max(1, displayMetrics.widthPixels)
            val height = max(1, displayMetrics.heightPixels)
            val density = displayMetrics.densityDpi
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            imageReader?.setOnImageAvailableListener({ reader -> consumeFrame(reader) }, projectionHandler)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post {
                        updateStatus("Tangkapan layar dihentikan oleh sistem/pengguna.")
                        stopSession()
                    }
                }
            }, projectionHandler)
            virtualDisplay = projection?.createVirtualDisplay(
                "StudyBuddyScreen",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                projectionHandler
            )
            createOverlay()
            updateStatus("Aktif. Buka materi latihan dan tekan Analisis layar saat diperlukan.")
        } catch (error: Exception) {
            updateStatus("Gagal memulai tangkapan layar: ${safeMessage(error)}")
            stopSession()
        }
    }

    private fun startVisibleForegroundService() {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("StudyBuddy sedang aktif")
            .setContentText("Tangkapan layar aktif dengan izin Anda. Ketuk notifikasi untuk membuka pengaturan.")
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "StudyBuddy screen helper",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi permanen untuk sesi tangkapan layar yang disetujui pengguna"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun createOverlay() {
        if (overlayView != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = rounded(Color.rgb(24, 31, 50), dp(18), Color.rgb(71, 86, 132))
            elevation = dp(10).toFloat()
        }
        val header = TextView(this).apply {
            text = "StudyBuddy AI  •  PANEL BELAJAR"
            textSize = 12f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(3), dp(4), dp(9))
        }
        root.addView(header)
        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var initialX = 0
            private var initialY = 0
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val params = overlayParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startY = event.rawY
                        initialX = params.x
                        initialY = params.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - startX).toInt()
                        params.y = initialY + (event.rawY - startY).toInt()
                        try { windowManager.updateViewLayout(root, params) } catch (_: Exception) { }
                        return true
                    }
                }
                return event.action == MotionEvent.ACTION_UP
            }
        })

        statusView = TextView(this).apply {
            text = "Menyiapkan sesi..."
            textSize = 12f
            setTextColor(Color.rgb(211, 219, 239))
            setPadding(dp(4), 0, dp(4), dp(8))
        }
        root.addView(statusView)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        buttons.addView(Button(this).apply {
            text = "Analisis layar"
            textSize = 12f
            setAllCaps(false)
            setOnClickListener { requestCapture() }
        }, LinearLayout.LayoutParams(0, dp(43), 1f))
        buttons.addView(Button(this).apply {
            text = "Tutup"
            textSize = 12f
            setAllCaps(false)
            setOnClickListener { stopSession() }
        }, LinearLayout.LayoutParams(dp(80), dp(43)))
        root.addView(buttons)

        val autoButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        autoButtons.addView(Button(this).apply {
            text = "Mulai otomatis"
            textSize = 11f
            setAllCaps(false)
            setOnClickListener { startAutoMode() }
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        autoButtons.addView(Button(this).apply {
            text = "Stop otomatis"
            textSize = 11f
            setAllCaps(false)
            setOnClickListener { stopAutoMode("Mode otomatis dihentikan pengguna.") }
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        root.addView(autoButtons)

        val divider = View(this).apply {
            setBackgroundColor(Color.rgb(66, 77, 106))
        }
        root.addView(divider, LinearLayout.LayoutParams(ViewGroupWidth.MATCH, dp(1)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })

        val resultScroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        resultView = TextView(this).apply {
            text = "Hasil analisis akan muncul di sini. Tekan tombol saat Anda ingin mengirim satu tangkapan layar ke Gemini."
            textSize = 13f
            setTextColor(Color.WHITE)
            setLineSpacing(dp(2).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        resultScroll.addView(resultView)
        root.addView(resultScroll, LinearLayout.LayoutParams(ViewGroupWidth.MATCH, dp(260)))

        val params = WindowManager.LayoutParams(
            dp(310),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = dp(90)
        }
        try {
            windowManager.addView(root, params)
            overlayView = root
            overlayParams = params
        } catch (error: Exception) {
            updateStatus("Panel overlay gagal dibuka: ${safeMessage(error)}")
        }
    }

    private fun startAutoMode() {
        if (projection == null || imageReader == null) {
            updateStatus("Sesi layar belum aktif. Mulai ulang dari aplikasi.")
            return
        }
        if (autoMode.compareAndSet(false, true)) {
            lastFrameDigest.set("")
            updateStatus("Mode otomatis aktif: analisis berkala setiap 10 detik. Tekan Stop otomatis kapan saja.")
            mainHandler.removeCallbacks(autoLoop)
            mainHandler.post(autoLoop)
        } else {
            updateStatus("Mode otomatis sudah aktif.")
        }
    }

    private fun stopAutoMode(message: String) {
        autoMode.set(false)
        mainHandler.removeCallbacks(autoLoop)
        updateStatus(message)
    }

    private fun requestCapture() {
        if (projection == null || imageReader == null) {
            updateStatus("Sesi belum aktif. Buka StudyBuddy dan mulai ulang.")
            return
        }
        if (!analysisInProgress.compareAndSet(false, true)) {
            updateStatus("Analisis sebelumnya masih berjalan. Tunggu hasilnya muncul.")
            return
        }
        if (!captureRequested.compareAndSet(false, true)) {
            analysisInProgress.set(false)
            updateStatus("Sedang mengambil gambar. Coba lagi sebentar.")
            return
        }
        updateStatus("Mengambil satu frame layar... tanpa klik atau memilih jawaban otomatis.")
    }

    private fun consumeFrame(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            if (!captureRequested.compareAndSet(true, false)) return
            val jpeg = imageToJpeg(image) ?: run {
                analysisInProgress.set(false)
                mainHandler.post { updateStatus("Frame tidak dapat dibaca. Coba tekan Analisis layar lagi.") }
                return
            }
            if (autoMode.get()) {
                val digest = java.security.MessageDigest.getInstance("SHA-256").digest(jpeg)
                    .joinToString("") { "%02x".format(it) }
                val previous = lastFrameDigest.getAndSet(digest)
                if (digest == previous) {
                    analysisInProgress.set(false)
                    mainHandler.post { updateStatus("Layar belum berubah; menunggu soal/halaman berikutnya...") }
                    return
                }
            }
            mainHandler.post {
                updateStatus("Gambar diterima. Mengirim ke Gemini model $model...")
                resultView?.text = "Sedang membaca teks dan menyusun penjelasan..."
            }
            networkExecutor.execute {
                val response = callGemini(jpeg)
                mainHandler.post {
                    analysisInProgress.set(false)
                    when {
                        response.startsWith("[STOP_SESSION]") -> {
                            stopAutoMode("Tidak ada soal aktif / sesi selesai / layar terhalang. Mode otomatis berhenti.")
                            resultView?.text = response.removePrefix("[STOP_SESSION]").trim()
                        }
                        response.startsWith("[ERROR]") -> {
                            stopAutoMode("Mode otomatis berhenti karena kendala API/koneksi. Periksa pengaturan lalu mulai lagi.")
                            resultView?.text = response.removePrefix("[ERROR]").trim()
                        }
                        else -> {
                            updateStatus(if (autoMode.get()) "Soal dianalisis. Menunggu perubahan layar..." else "Selesai. Tinjau hasilnya, lalu tentukan tindakan sendiri.")
                            resultView?.text = response.trim()
                        }
                    }
                }
            }
        } catch (error: Exception) {
            captureRequested.set(false)
            analysisInProgress.set(false)
            mainHandler.post { updateStatus("Gagal membaca frame: ${safeMessage(error)}") }
        } finally {
            try { image?.close() } catch (_: Exception) { }
        }
    }

    private fun imageToJpeg(image: Image): ByteArray? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0 || rowStride <= 0) return null
        val width = image.width
        val height = image.height
        val paddedWidth = width + (rowStride - pixelStride * width) / pixelStride
        val paddedBitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        paddedBitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height)
        if (cropped !== paddedBitmap) paddedBitmap.recycle()
        val maxWidth = 1440
        val finalBitmap = if (cropped.width > maxWidth) {
            val newHeight = (cropped.height * (maxWidth.toFloat() / cropped.width)).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(cropped, maxWidth, newHeight, true).also { if (it !== cropped) cropped.recycle() }
        } else cropped
        return try {
            ByteArrayOutputStream().use { output ->
                finalBitmap.compress(Bitmap.CompressFormat.JPEG, 82, output)
                output.toByteArray()
            }
        } finally {
            finalBitmap.recycle()
        }
    }

    private fun callGemini(imageBytes: ByteArray): String {
        var connection: HttpURLConnection? = null
        return try {
            val encodedImage = Base64.encodeToString(imageBytes, Base64.NO_WRAP)
            val prompt = """
                Anda adalah asisten belajar yang jelas dan jujur. Analisis tangkapan layar ini untuk membantu pengguna memahami materi latihan.
                1. Transkripsikan soal dan pilihan yang terbaca, tanpa mengarang bagian yang buram.
                2. Jelaskan konsep dan proses penalaran secara ringkas.
                3. Untuk soal pilihan ganda latihan, sebutkan pilihan yang paling mungkin beserta alasan dan tingkat keyakinan; jika teks kurang jelas, minta gambar yang lebih jelas.
                4. Jika terdapat beberapa soal, jawab per nomor.
                5. Abaikan elemen panel aplikasi yang bukan bagian dari materi.
                6. Jika layar jelas tidak memuat soal/latihan yang dapat dianalisis, atau tampak seperti halaman selesai/hasil akhir, login, CAPTCHA, izin, blokir, atau layar error, awali jawaban dengan token persis [STOP_SESSION] lalu jelaskan alasannya.
                7. Jika soal latihan aktif terlihat, jangan sertakan token [STOP_SESSION].
                Jangan mencoba mengontrol perangkat, mengklik tombol, mengisi formulir, atau menyembunyikan aktivitas aplikasi. Berikan penjelasan yang bisa dipakai untuk belajar.
            """.trimIndent()

            val partArray = JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inlineData", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", encodedImage)))
            val body = JSONObject().put("contents", JSONArray().put(
                JSONObject().put("role", "user").put("parts", partArray)
            )).put("generationConfig", JSONObject()
                .put("temperature", 0.2)
                .put("maxOutputTokens", 1400))

            val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            connection = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 80000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val responseText = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
            if (status !in 200..299) {
                val message = json.optJSONObject("error")?.optString("message")
                    ?.takeIf { it.isNotBlank() } ?: "HTTP $status"
                return "[ERROR] Gemini API (HTTP $status): $message"
            }
            val candidates = json.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val parts = firstCandidate?.optJSONObject("content")?.optJSONArray("parts")
            val answer = buildString {
                if (parts != null) {
                    for (index in 0 until parts.length()) {
                        val text = parts.optJSONObject(index)?.optString("text").orEmpty()
                        if (text.isNotBlank()) {
                            if (isNotEmpty()) append("\n\n")
                            append(text)
                        }
                    }
                }
            }.trim()
            if (answer.isBlank()) "Respons Gemini kosong atau tidak memiliki teks yang dapat ditampilkan. Coba model lain atau tangkap ulang layar." else answer
        } catch (error: Exception) {
            "[ERROR] ${safeMessage(error)}"
        } finally {
            connection?.disconnect()
        }
    }

    private fun updateStatus(message: String) {
        mainHandler.post { statusView?.text = message }
    }

    private fun stopSession() {
        if (stopping) return
        stopping = true
        autoMode.set(false)
        mainHandler.removeCallbacks(autoLoop)
        captureRequested.set(false)
        analysisInProgress.set(false)
        try { windowManager.let { wm -> overlayView?.let { wm.removeView(it) } } } catch (_: Exception) { }
        overlayView = null
        statusView = null
        resultView = null
        overlayParams = null
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) { }
        try { imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        val activeProjection = projection
        projection = null
        try { activeProjection?.stop() } catch (_: Exception) { }
        apiKey = ""
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopping) {
            stopping = true
            autoMode.set(false)
            mainHandler.removeCallbacks(autoLoop)
            captureRequested.set(false)
            analysisInProgress.set(false)
            try { overlayView?.let { windowManager.removeView(it) } } catch (_: Exception) { }
            try { virtualDisplay?.release() } catch (_: Exception) { }
            try { imageReader?.close() } catch (_: Exception) { }
            try { projection?.stop() } catch (_: Exception) { }
        }
        networkExecutor.shutdownNow()
        projectionThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun safeMessage(error: Throwable): String =
        error.message?.take(240)?.ifBlank { error.javaClass.simpleName } ?: error.javaClass.simpleName

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radiusPx: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx.toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private object ViewGroupWidth {
        const val MATCH = -1
    }
}
