package com.arfi.studybuddy

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        private const val SCREEN_CAPTURE_REQUEST_CODE = 7310
        private const val NOTIFICATION_REQUEST_CODE = 7311
    }

    private lateinit var apiKeyInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        buildScreen()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(Color.rgb(247, 248, 252))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(outer)
        }

        outer.addView(TextView(this).apply {
            text = "StudyBuddy AI"
            textSize = 30f
            setTextColor(Color.rgb(23, 32, 51))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        outer.addView(TextView(this).apply {
            text = "Asisten belajar visual berbasis Gemini"
            textSize = 15f
            setTextColor(Color.rgb(83, 109, 254))
            setPadding(0, dp(4), 0, dp(18))
        })

        outer.addView(label("Gemini API key"))
        apiKeyInput = EditText(this).apply {
            hint = "Tempel API key dari Google AI Studio"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            singleLine = true
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        outer.addView(apiKeyInput, matchWidth())
        outer.addView(TextView(this).apply {
            text = "Kunci hanya disimpan di memori selama sesi ini, tidak dicatat ke log atau disimpan di preferensi."
            textSize = 12f
            setTextColor(Color.rgb(100, 110, 128))
            setPadding(0, dp(5), 0, dp(16))
        })

        outer.addView(label("Model AI Gemini"))
        modelInput = EditText(this).apply {
            setText("gemini-3.8-flash")
            hint = "Contoh: gemini-3.8-flash"
            inputType = InputType.TYPE_CLASS_TEXT
            singleLine = true
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        outer.addView(modelInput, matchWidth())
        outer.addView(TextView(this).apply {
            text = "Isi ID model yang benar-benar tersedia di akun Gemini API Anda. Ketersediaan model dapat berubah; periksa Google AI Studio."
            textSize = 12f
            setTextColor(Color.rgb(100, 110, 128))
            setPadding(0, dp(5), 0, dp(18))
        })

        val startButton = Button(this).apply {
            text = "Aktifkan panel belajar"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(66, 85, 220)))
            setOnClickListener { startStudySession() }
        }
        outer.addView(startButton, matchWidth())

        outer.addView(TextView(this).apply {
            text = "Cara pakai"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(23, 32, 51))
            setPadding(0, dp(24), 0, dp(8))
        })
        outer.addView(TextView(this).apply {
            text = "1. Masukkan API key Gemini dan ID model yang tersedia pada akun Anda.\n2. Aktifkan izin tampil di atas aplikasi lain.\n3. Setujui dialog perekaman layar Android secara eksplisit.\n4. Di panel, pilih Analisis layar untuk satu kali analisis atau Mulai otomatis untuk analisis berkala setiap 10 detik.\n5. Mode otomatis mencoba berhenti jika Gemini mendeteksi tidak ada soal, halaman selesai/terhalang, atau jika terjadi error API. Deteksi visual tidak selalu sempurna; hentikan secara manual jika perlu.\n6. Baca penjelasan dan tentukan tindakan sendiri pada materi latihan yang mengizinkan bantuan AI.\n\nPrivasi: screenshot dikirim ke Gemini saat dianalisis. Hindari menampilkan kata sandi atau data sensitif. Android menampilkan indikator/notifikasi screen capture; aplikasi tidak menyembunyikan aktivitas, mengakali deteksi situs, atau menekan jawaban otomatis."
            textSize = 14f
            setTextColor(Color.rgb(67, 76, 95))
            setLineSpacing(dp(3).toFloat(), 1f)
        })

        outer.addView(Button(this).apply {
            text = "Hentikan sesi / tutup panel"
            setOnClickListener {
                val stopIntent = Intent(this@MainActivity, ScreenHelperService::class.java).apply {
                    action = ScreenHelperService.ACTION_STOP
                }
                if (android.os.Build.VERSION.SDK_INT >= 26) startService(stopIntent) else startService(stopIntent)
                Toast.makeText(this@MainActivity, "Perintah hentikan sesi dikirim.", Toast.LENGTH_SHORT).show()
            }
        }, matchWidth().apply { topMargin = dp(16) })

        if (android.os.Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
        }
        setContentView(scroll)
    }

    private fun startStudySession() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Izinkan notifikasi agar status sesi tangkapan layar tetap terlihat.", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_REQUEST_CODE)
            return
        }
        val apiKey = apiKeyInput.text?.toString()?.trim().orEmpty()
        val model = normalizeModel(modelInput.text?.toString().orEmpty())
        if (apiKey.isBlank()) {
            apiKeyInput.error = "API key wajib diisi"
            apiKeyInput.requestFocus()
            return
        }
        if (!model.matches(Regex("[A-Za-z0-9._-]{2,100}"))) {
            modelInput.error = "ID model tidak valid"
            modelInput.requestFocus()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan StudyBuddy tampil di atas aplikasi lain, lalu tekan tombol ini lagi.", Toast.LENGTH_LONG).show()
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(permissionIntent)
            return
        }
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager.createScreenCaptureIntent(), SCREEN_CAPTURE_REQUEST_CODE)
    }

    @Deprecated("Uses the platform permission result callback")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_REQUEST_CODE) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                startStudySession()
            } else {
                Toast.makeText(this, "Izin notifikasi diperlukan agar indikator sesi jelas. Aktifkan di pengaturan aplikasi.", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Uses the platform MediaProjection consent activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != SCREEN_CAPTURE_REQUEST_CODE) return
        if (resultCode != Activity.RESULT_OK || data == null) {
            Toast.makeText(this, "Izin tangkapan layar dibatalkan.", Toast.LENGTH_SHORT).show()
            return
        }
        val serviceIntent = Intent(this, ScreenHelperService::class.java).apply {
            action = ScreenHelperService.ACTION_START
            putExtra(ScreenHelperService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenHelperService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenHelperService.EXTRA_API_KEY, apiKeyInput.text?.toString()?.trim().orEmpty())
            putExtra(ScreenHelperService.EXTRA_MODEL, normalizeModel(modelInput.text?.toString().orEmpty()))
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        Toast.makeText(this, "StudyBuddy aktif. Pindah ke layar belajar, lalu gunakan panel overlay.", Toast.LENGTH_LONG).show()
    }

    private fun normalizeModel(value: String): String = value.trim().removePrefix("models/")

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(45, 54, 75))
        setPadding(0, 0, 0, dp(7))
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
