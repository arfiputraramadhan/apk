# StudyBuddy AI — Android source project

StudyBuddy adalah prototipe Android untuk membantu memahami materi belajar dari satu tangkapan layar yang dipilih pengguna. AI menerima gambar melalui Gemini API lalu menampilkan transkripsi, penalaran, dan saran jawaban latihan di panel overlay. Aplikasi **tidak menekan pilihan jawaban, tidak mengisi formulir, dan tidak menyamarkan aktivitasnya**.

## Fitur

- Panel overlay yang dapat dipindah ke posisi lain dan menampilkan hasil.
- Tangkapan layar berbasis Android MediaProjection dengan persetujuan sistem setiap sesi.
- Kolom untuk API key Gemini dan ID model yang dapat diubah.
- Analisis hanya terjadi setelah tombol `Analisis layar` ditekan; tidak ada pengambilan otomatis berkala.
- Notifikasi foreground yang terlihat ketika sesi tangkapan layar aktif.
- Kunci API hanya disimpan di memori selama sesi, tidak ditulis ke file aplikasi/log.
- Gambar diperkecil hingga lebar maksimum 1440 px dan dikirim sebagai JPEG untuk mengurangi beban permintaan.
- Penanganan error API, koneksi, izin, dan penghentian sesi.

## Cara membuka dan membangun

1. Instal Android Studio versi modern dengan Android SDK Platform 35 dan JDK 17.
2. Ekstrak ZIP, lalu buka folder `studybuddy-android` sebagai proyek di Android Studio.
3. Lakukan Gradle Sync. Gradle/Android Gradle Plugin mungkin perlu diunduh melalui Android Studio.
4. Pilih perangkat Android (minimum Android 8.0 / API 26), lalu jalankan konfigurasi `app`.
5. Untuk membuat APK: **Build → Build APK(s)**. Android Studio menampilkan lokasi file APK setelah build selesai.

Catatan: ZIP ini berisi source project, bukan APK siap pasang. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle sehingga APK belum dapat dikompilasi atau diuji pada emulator di sini.

## Menyiapkan Gemini API

1. Buat API key pada [Google AI Studio](https://aistudio.google.com/apikey).
2. Jalankan aplikasi dan tempel API key ke kolom yang tersedia.
3. ID default adalah `gemini-3.8-flash`. ID model dapat diubah menjadi model multimodal lain yang kompatibel dengan endpoint `generateContent` dan tersedia untuk akun Anda, misalnya `gemini-3.6-flash`.
4. Penggunaan API dapat dikenai batas kuota/biaya sesuai pengaturan akun Google. Lihat [dokumentasi Gemini API](https://ai.google.dev/api/generate-content) dan [daftar model](https://ai.google.dev/gemini-api/docs/models).

## Menggunakan panel

1. Masukkan API key dan ID model.
2. Tekan **Aktifkan panel belajar**.
3. Izinkan `Tampil di atas aplikasi lain` jika diminta.
4. Setujui dialog sistem tangkapan layar Android. Pilih seluruh layar jika sistem menawarkan pilihan cakupan dan Anda memang memerlukannya. Android dapat menampilkan indikator perekaman layar selama sesi berlangsung.
5. Buka materi/soal latihan. Geser header panel untuk memindahkan panel.
6. Tekan **Analisis layar**. Satu frame dikirim ke Gemini, lalu hasilnya ditampilkan di panel. Pengguna tetap memilih tindakan sendiri.
7. Tekan **Tutup** untuk menghentikan sesi dan melepaskan izin tangkapan layar.

## Privasi dan batasan

- Jangan gunakan saat ujian/asesmen yang melarang bantuan AI atau tangkapan layar.
- Jangan tampilkan kata sandi, data pembayaran, pesan pribadi, atau data sensitif dalam gambar yang dianalisis.
- Gambar dikirim ke layanan Gemini milik Google untuk diproses; periksa kebijakan privasi dan retensi Google sebelum penggunaan.
- Aktivitas tangkapan layar ditampilkan melalui kontrol sistem/notifikasi Android. Proyek ini tidak dirancang untuk melewati sistem pengawasan atau menyembunyikan perpindahan aplikasi.
- Aplikasi sumber pihak ketiga dapat menolak perekaman layar. Materi terlindungi dapat muncul hitam/kosong.
- Akurasi pembacaan visual tidak dijamin. Tinjau hasil AI, terutama jika teks kecil, terpotong, atau buram.

## Struktur singkat

```text
studybuddy-android/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/arfi/studybuddy/
│       │   ├── MainActivity.kt
│       │   └── ScreenHelperService.kt
│       └── res/values/styles.xml
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```
